# Bus-Attendance-App
Bus Attendance App ECC
App for entering students who enter the bus and sending text message to parents.
